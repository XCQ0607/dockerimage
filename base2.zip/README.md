# Base - 轻量级容器化服务集成平台

[![Docker](https://img.shields.io/badge/docker-%230db7ed.svg?style=for-the-badge&logo=docker&logoColor=white)](https://www.docker.com/)
[![Ubuntu](https://img.shields.io/badge/ubuntu-%23E95420.svg?style=for-the-badge&logo=ubuntu&logoColor=white)](https://ubuntu.com/)

Base 是一个基于 Docker 的轻量级容器化服务集成平台，主要用于部署和运行网络代理与远程终端工具。它整合了 Xray（网络代理）、ttyd（Web 终端）和 cloudflared（Cloudflare 隧道）等工具，适用于需要通过 Web 访问命令行或穿透内网的场景。

## 🎯 目标用户

- 开发者
- 运维人员
- 需要内网穿透或远程终端访问能力的技术用户

## 🌟 核心特性

- **多服务集成**：在一个容器中集成 Xray、ttyd 和 cloudflared
- **自动化部署**：通过 Docker 容器化部署，一键启动所有服务
- **内网穿透**：通过 Cloudflare Tunnel 安全暴露本地服务到公网
- **Web 终端**：基于 Web 的终端访问，无需 SSH 客户端
- **定时任务**：内置备份、健康检查和保活等定时任务系统
- **环境变量配置**：通过环境变量灵活配置各项服务参数
- **R2 云存储**：支持 Cloudflare R2 对象存储的备份与恢复

## 🛠️ 集成工具

### 1. Xray-core

- **用途**：网络代理工具
- **版本**：GitHub 最新 Linux 64 位版本
- **配置**：通过 `/app/xy/config.json` 进行配置
- **文档**：[Xray-core GitHub](https://github.com/XTLS/Xray-core)

### 2. ttyd

- **用途**：Web 终端访问工具
- **版本**：GitHub 最新 x86_64 版本
- **端口**：80
- **文档**：[ttyd GitHub](https://github.com/tsl0922/ttyd)

### 3. cloudflared

- **用途**：Cloudflare Tunnel 客户端
- **版本**：GitHub 最新 Linux AMD64 版本
- **功能**：安全地将本地服务暴露到公网
- **文档**：[cloudflared GitHub](https://github.com/cloudflare/cloudflared)

### 4. supercronic

- **用途**：定时任务管理器
- **版本**：GitHub 最新 Linux AMD64 版本
- **功能**：管理容器中的 cron 任务
- **文档**：[supercronic GitHub](https://github.com/aptible/supercronic)

### 5. supervisord

- **用途**：进程管理器
- **功能**：统一管理容器中的多个后台服务
- **配置**：通过 `/app/supervisor/supervisord.conf` 进行配置
- **文档**：[Supervisor](http://supervisord.org/)

## 📁 项目结构

```
.
├── app/                         # 应用程序目录
│   ├── backup/                 # 备份相关脚本
│   │   ├── backup.sh           # R2 备份脚本
│   │   ├── restore.sh          # R2 恢复脚本
│   │   ├── backup-manager.sh   # 通用备份管理器
│   │   └── check-r2-connectivity.sh  # R2 连接性检查脚本
│   ├── cron/                   # 定时任务配置
│   │   └── my-crontab          # crontab 配置文件
│   ├── supervisor/             # 进程管理配置
│   │   └── supervisord.conf    # supervisord 配置文件
│   ├── xy/                     # Xray 配置
│   │   └── config.json         # Xray 核心配置文件
│   ├── healthcheck.sh          # 健康检查脚本
│   ├── keepalive.sh            # 保活脚本
│   └── setup-cron.sh           # 定时任务设置脚本
├── Dockerfile                  # Docker 构建文件
└── entrypoint.sh               # 容器入口脚本
```

## 🚀 快速开始

### 构建镜像

```bash
docker build -t base-image .
```

### 运行容器

```bash
docker run -d \
  -p 7860:7860 \
  -e UUID=your-uuid-here \
  -e DOMAIN=your-domain.hf.space \
  -e ARGO_PAT=your-cloudflare-pat \
  --name base-container \
  base-image
```

### 环境变量配置

| 变量名       | 默认值                                   | 说明            |
| ------------ | ---------------------------------------- | --------------- |
| `TZ`       | `Asia/Shanghai`                        | 时区设置        |
| `UUID`     | `2982f122-9649-40dc-bc15-fa3ec91d8921` | Xray UUID       |
| `DOMAIN`   | `web3x-p.hf.space`                     | 域名设置        |
| `ARGO_PAT` | (空)                                     | Cloudflared PAT |

### R2 备份相关环境变量

| 变量名                   | 默认值          | 说明                             |
| ------------------------ | --------------- | -------------------------------- |
| `R2_ACCESS_KEY_ID`     | (空)            | R2 访问密钥 ID                   |
| `R2_SECRET_ACCESS_KEY` | (空)            | R2 密钥                          |
| `R2_ENDPOINT`          | (空)            | R2 端点地址                      |
| `R2_BUCKET_NAME`       | (空)            | R2 存储桶名称                    |
| `BACKUP_NAME`          | `program`     | 备份文件名前缀                   |
| `BACKUP_SOURCE_DIR`    | `/app/data`   | 备份源目录                       |
| `BACKUP_DEST_DIR`      | `/tmp`        | 备份目标目录                     |
| `BACKUP_START_SCRIPT`  | (空)            | 备份前执行的脚本路径             |
| `BACKUP_STOP_SCRIPT`   | (空)            | 备份前停止服务的脚本路径         |
| `RESTORE_TARGET_DIR`   | `/app/data`   | 恢复目标目录                     |
| `RESTORE_SOURCE_DIR`   | `data`        | 恢复源目录（在备份文件中的路径） |
| `RESTORE_DEST_DIR`     | `/tmp`        | 恢复文件下载目录                 |
| `RESTORE_START_SCRIPT` | (空)            | 恢复后启动服务的脚本路径         |
| `RESTORE_STOP_SCRIPT`  | (空)            | 恢复前停止服务的脚本路径         |
| `KEEP_BACKUPS`         | `5`           | 保留备份文件数量                 |
| `BACKUP_TIME`          | `0-0-0-1-0-0` | 备份时间设置                     |
| `backup_on`            | `true`        | 是否启用备份功能                 |
| `keep_time`            | `0-0-0-0-5-0` | 保活任务执行间隔时间             |

### 健康检查相关环境变量

| 变量名              | 默认值          | 说明                             |
| ------------------- | --------------- | -------------------------------- |
| `HC_PORT`         | `7860`        | 健康检查端口                     |
| `HC_TIME`         | `0-0-0-0-1-0` | 健康检查时间设置                 |
| `HC_START_SCRIPT` | (空)            | 健康检查失败时启动服务的脚本路径 |
| `HC_SERVICE_NAME` | `program`     | 健康检查服务名称                 |
| `hc_on`           | `true`        | 是否启用健康检查功能             |

## ⚙️ 功能详解

### 1. 定时任务系统

Base 提供了强大的定时任务系统，支持以下三种任务类型：

1. **备份任务**：定期将指定目录的数据备份到 R2 存储
2. **健康检查任务**：定期检查服务状态并在必要时重启服务
3. **保活任务**：定期执行 HTTP 请求以保持服务活跃

所有定时任务通过 `setup-cron.sh` 脚本统一管理，支持多种时间格式：

- 标准 cron 表达式：如 `*/5 * * * *`
- 纯数字（分钟）：如 `5`
- X-YEAR-X-MONTH-X-D-X-H-X-M 格式：如 `0-0-0-1-0-0`（每小时执行一次）

### 2. R2 备份与恢复

Base 集成了 Cloudflare R2 对象存储的备份与恢复功能：

- **备份策略**：每小时执行一次备份，生成时间戳命名的 zip 文件
- **保留策略**：保留最近 5 次备份并自动清理旧备份
- **恢复机制**：容器启动时优先检查 R2 存储桶，若有最新备份则先下载恢复再启动应用服务

### 3. 通用备份管理器

Base 提供了一个通用的备份管理器脚本 `/app/backup/backup-manager.sh`，支持以下功能：

- 手动执行备份
- 手动恢复备份
- 列出所有备份文件
- 删除旧备份
- 设置保留备份数量

使用方法：

```bash
# 进入容器
docker exec -it base-container /bin/bash

# 执行手动备份
/app/backup/backup-manager.sh --backup

# 恢复最新备份
/app/backup/backup-manager.sh --restore

# 列出所有备份
/app/backup/backup-manager.sh --list

# 删除旧备份，保留最近3个
/app/backup/backup-manager.sh --delete-old 3

# 设置保留备份数量为10
/app/backup/backup-manager.sh --set-keep-count 10
```

### 4. 多域名支持

保活脚本支持多域名配置：

- 通过 `DOMAINS` 环境变量设置多个域名（逗号、空格或换行分隔）
- 若 `DOMAINS` 不存在则回退到 `DOMAIN` 环境变量

## 🔧 开发与调试

### 本地调试

```
# 挂载配置文件进行热更新测试
docker run -d \
  -p 7860:7860 \
  -v $(pwd)/app:/app \
  -e UUID=your-uuid-here \
  -e DOMAIN=your-domain.hf.space \
  -e ARGO_PAT=your-cloudflare-pat \
  --name base-container \
  base-image
```

### 查看日志

```bash
docker logs -f base-container
```

### 进入容器

```bash
docker exec -it base-container /bin/bash
```

## 📊 性能与安全

### 性能要求

- 低资源消耗，适合边缘设备或小型 VPS
- 需保证网络连通性和稳定性，尤其对于 tunnel 场景

### 安全要求

- 不应在生产环境中硬编码敏感信息（如 ARGO_PAT）
- 建议使用 Docker Secrets 或环境变量注入方式传递凭证
- 已创建普通用户 `user`（UID=1000），但部分服务仍可能以 root 运行

## ⚠️ 已知问题和风险

1. 所有服务运行在同一容器中，不符合严格微服务隔离原则
2. cloudflared 需要有效 PAT（API Token），否则无法建立隧道
3. 依赖外部 GitHub 下载地址，可能受网络限制（需科学上网）
4. 使用 root 权限安装软件包，存在潜在安全风险（尽管最终以普通用户运行）
5. `chmod -R 777 /app` 存在安全隐患，建议改为最小权限
6. 没有健康检查机制（HEALTHCHECK）
7. 缺少日志轮转配置
8. 未提供 HTTPS 终结或反向代理配置

## 📄 许可证

本项目基于 MIT 许可证开源，详情请参见 [LICENSE](LICENSE) 文件。

## 🤝 贡献

欢迎提交 Issue 和 Pull Request 来改进这个项目！
